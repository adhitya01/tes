<?php
require_once(__DIR__.'/eligible_func.php');

$remember_user_token = 'eyJfcmFpbHMiOnsibWVzc2FnZSI6IlcxczVNVEEyTkRnNFhTd2lKREpoSkRFd0pGWkRPWGc1ZWxSSFpraFBlVkl6UTBGMldXcEZOMDhpTENJeE5qTXhOVFV3TnpJM0xqa3pPVFU0TkNKZCIsImV4cCI6IjIwMjMtMDktMTNUMTY6MzI6MDcuOTM5WiIsInB1ciI6ImNvb2tpZS5yZW1lbWJlcl91c2VyX3Rva2VuIn19--9e027f68e53961a9a5886195250b6144575e537c';

if (uri_extension($_SERVER['REQUEST_URI']) == 'm3u8' && isset($_GET['channel']) && ctype_digit($_GET['channel'])) {
  $vidioID = filter_input(INPUT_GET,"channel",FILTER_SANITIZE_STRING);
} else {
  http_response_code(404);
  include($_SERVER['DOCUMENT_ROOT'] . '/404.shtml');
  die();
}

$m3u8_url = 'https://www.vidio.com/videos/'.$vidioID.'/common_tokenized_playlist.m3u8';
$userAgent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15';

if (is_url_alive($m3u8_url)) {
  $hls_output = get_original_url($m3u8_url, $userAgent);
  if (isset($hls_output) && !empty($hls_output)) {
  	echo $hls_output;
  } else {
  	echo $offline_string;
    die();
  }
} else {
  $vidioCookie_file = __DIR__.'/vidio-cookie.json';
  $vidioCache_file = __DIR__.'/vidio-cache/vod/'.$vidioID.'.json';
  if (file_exists($vidioCache_file)) {   
    $json = file_get_contents($vidioCache_file,0,NULL,NULL);
    $vidioCacheArray = json_decode($json,TRUE);
    if ( time() - 100 < $vidioCacheArray['expired'] ) {
      echo $vidioCacheArray['hls'];
  	  die();
  	}
  	if ( array_key_exists('m3u8', $vidioCacheArray) && is_url_alive($vidioCacheArray['m3u8']) ) {
      $hls_output = get_original_url($vidioCacheArray['m3u8'], $userAgent);
      if (isset($hls_output) && !empty($hls_output)) {
        $vidioCache['hls'] = $hls_output;
        $vidioCache['m3u8'] = $vidioCacheArray['m3u8'];
        $vidioCache['expired'] = (int) time() + 14400;
        $fp = fopen($vidioCache_file, 'w');
        fwrite($fp, json_encode($vidioCache, JSON_PRETTY_PRINT));
        fclose($fp);
      
        echo $hls_output;
  	    die();
      }
    }
  }
  if (!file_exists($vidioCookie_file)) {   
    echo $offline_string;
    die();
  }
  $cookieJson = file_get_contents($vidioCookie_file,0,null,null);
  $cookieArray = json_decode($cookieJson,true);  
  
  $vidio_Header = array(
    'Accept: application/json, text/javascript, */*; q=0.01',
    'Cookie: '.$cookieArray['cookie'].'; remember_user_token=;'.$remember_user_token,
    'Accept-Language: en-us',
    'Host: www.vidio.com',
    'User-Agent: '.$userAgent,
    'Accept-Encoding: gzip, deflate, br',
    'Connection: keep-alive',
    'X-Requested-With: XMLHttpRequest'
  );
  
  $token_vidio_url = 'https://www.vidio.com/interactions_stream.json?video_id='.$vidioID.'&type=videos';
  
  $arrayResult = getDataFromCurlWithHeaderCookie($token_vidio_url, $vidio_Header);
  
//   print_r($arrayResult);
//   die();
  
  if (empty($arrayResult) || !array_key_exists('_vidio_session', $arrayResult) || !array_key_exists('result', $arrayResult) || !isJson($arrayResult['result'])) {
  	echo $offline_string;
    die();
  }
  
  $newCookie['cookie'] = "_vidio_session=".$arrayResult['_vidio_session'];
  $fp = fopen($vidioCookie_file, 'w');
  fwrite($fp, json_encode($newCookie, JSON_PRETTY_PRINT));
  fclose($fp);
  
  $newHLSArray = json_decode($arrayResult['result'], true);
  if (empty($newHLSArray) || !array_key_exists('source', $newHLSArray)) {
    echo $offline_string;
    die();
  }
  $newHLS = $newHLSArray['source'];

  if (is_url_alive($newHLS)) {
    $hls_output = get_original_url($newHLS, $userAgent);
    if (isset($hls_output) && !empty($hls_output)) {
      $vidioCache['hls'] = $hls_output;
      $vidioCache['m3u8'] = $newHLS;
      $vidioCache['expired'] = (int) time() + 14400;
      $fp = fopen($vidioCache_file, 'w');
      fwrite($fp, json_encode($vidioCache, JSON_PRETTY_PRINT));
      fclose($fp);
      
  	  echo $hls_output;
  	  die();
    } else {
  	  echo $offline_string;
      die();
    }
  }
}