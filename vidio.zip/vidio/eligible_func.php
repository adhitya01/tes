<?php
date_default_timezone_set('Asia/Singapore');
require_once(__DIR__.'/simplehtmldom_1_9_1/simple_html_dom.php');

$protocol = (isset($_SERVER['HTTPS']) &&
    ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
    isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
    $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') ? "https" : "http";
$domain = rtrim($_SERVER['HTTP_HOST'], "/ ");
$currentdir = rtrim(dirname($_SERVER['PHP_SELF']), "/");

$fullpath = (empty($currentdir) ? $protocol.'://'.$domain : $protocol.'://'.$domain.$currentdir);

$offline_string = <<<'EOD'
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:2
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-DISCONTINUITY-SEQUENCE:0
#EXT-X-DISCONTINUITY
#EXTINF:2.000000,
technicalissue0.ts
#EXTINF:2.000000,
technicalissue1.ts
#EXTINF:2.000000,
technicalissue2.ts
#EXTINF:2.000000,
technicalissue3.ts
#EXTINF:2.000000,
technicalissue4.ts
#EXTINF:2.000000,
technicalissue5.ts
#EXTINF:2.000000,
technicalissue6.ts
#EXT-X-ENDLIST
EOD;

function getLastLines($string, $n = 1) {
    $lines = explode("\n", $string);
    $lines = array_filter($lines);
    $lines = array_slice($lines, -$n);
    return implode("\n", $lines);
}

function isJson($string) {
   json_decode($string);
   return json_last_error() === JSON_ERROR_NONE;
}


function uri_extension($uri) {
  $url_parts = parse_url($uri);
  $extension = strtolower(pathinfo($url_parts['path'], PATHINFO_EXTENSION));
  
  return $extension;
}

function contains_word ($words, $wordcheck) {
  foreach($words as $word) {
    if (preg_match("/{$word}/i", $wordcheck)) {
    	return true;
    }
  }
  return false;
}

function is_url_alive($url, $user_agent='', $referer = '') {
/*HTTP response status codes indicate whether a specific HTTP request has been successfully completed. Responses are grouped in five classes:
- Informational responses (100–199)
- Successful responses (200–299)
- Redirects (300–399)
- Client errors (400–499)
- Server errors (500–599)*/

  $curl = curl_init($url);
  $alive = TRUE;

  // Use curl_setopt() to set an option for cURL transfer 
  //curl_setopt($curl, CURLOPT_NOBODY, true); 
  curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => array(
      'Accept: */*',
      'Connection: Keep-Alive',
      'Host: '.parse_url($url, PHP_URL_HOST),
      'Accept-Language: en-us',
      'User-Agent: '.$user_agent,
      'Referer: '.$referer,
      'Accept-Encoding: gzip'
    ),
  ));
  
  // Use curl_exec() to perform cURL session 
  $result = curl_exec($curl); 
  if ($result !== FALSE) { 
    $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);  
    if ( ($statusCode >= 400 && $statusCode < 405) || $statusCode > 405) { //Supposed >=400 but for DAAI it's >405 
        $alive = FALSE;
    } 
  } 
  else { 
    $alive = FALSE;
  } 
  return $alive;
}

function getDataFromCurlWithHeaderCookie($urlAPI, $headersAPI = NULL, $bodyAPI = NULL, $methodAPI='GET', $curlOPT = NULL) {
  try {
    $curl = curl_init();
    $curlOptArray = array(
      CURLOPT_URL => $urlAPI,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HEADER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => $methodAPI,
    );

    if (!empty($headersAPI)) {
    	$curlOptArray[CURLOPT_HTTPHEADER] = $headersAPI;
    }
    if (!empty($bodyAPI)) {
    	$curlOptArray[CURLOPT_POSTFIELDS] = $bodyAPI;
    }  
    if (!empty($curlOPT)) {
      foreach($curlOPT as $key => $value) {
          $curlOptArray[$key] = $value;
      }
    }
    if ($methodAPI === 'POST') {
      $curlOptArray[CURLOPT_SAFE_UPLOAD] = TRUE;
    }
    curl_setopt_array($curl, $curlOptArray);
    $response = curl_exec($curl);
    curl_close($curl);
    
//     echo $response;
//     echo "\r\n<br>\r\n<br>";
    //die();
    preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $response,  $match_found);
    $cookies = array();
    foreach($match_found[1] as $item) {
      parse_str($item,  $cookie);
      $cookies = array_merge($cookies,  $cookie);
    }
    
    $resultArray = array_slice(explode(PHP_EOL, $response), -1, 1);
    $result['result'] = $resultArray[0];
    $output = array_merge($cookies, $result);
    
//     print_r($output);
//     echo "\r\n<br>\r\n<br>";
    return $output;
  }
  catch (Exception $e) {
    return array();
  }
}

function getDataFromCurl($urlAPI, $headersAPI = NULL, $bodyAPI = NULL, $methodAPI='GET', $curlOPT = NULL, $returnJSON = TRUE) {
  try {
    $curl = curl_init();
    $curlOptArray = array(
      CURLOPT_URL => $urlAPI,
      CURLOPT_RETURNTRANSFER => TRUE,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => TRUE,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => $methodAPI
    );

    if (!empty($headersAPI)) {
    	$curlOptArray[CURLOPT_HTTPHEADER] = $headersAPI;
    }
    if (!empty($bodyAPI)) {
    	$curlOptArray[CURLOPT_POSTFIELDS] = $bodyAPI;
    }  
    if (!empty($curlOPT)) {
      foreach($curlOPT as $key => $value) {
          $curlOptArray[$key] = $value;
      }
    }
    if ($methodAPI === 'POST') {
      $curlOptArray[CURLOPT_SAFE_UPLOAD] = TRUE;
    }
    curl_setopt_array($curl, $curlOptArray);
    $response = curl_exec($curl);
    curl_close($curl);

    if ($returnJSON) {
      return json_decode($response, TRUE);
    } else {
      return $response;
    }
  }
  catch (Exception $e) {
    return array();
  }
}

function get_original_url($url, $user_agent='', $referer='') {
  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => array(
      'Accept: */*',
      'Connection: Keep-Alive',
      'Host: '.parse_url($url, PHP_URL_HOST),
      'Accept-Language: en-us',
      'User-Agent: '.$user_agent,
      'Referer: '.$referer,
      'Accept-Encoding: gzip'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);
  return $response;
}

function array_key_value_exists($array, $key, $val) {
    foreach ($array as $item)
        if (isset($item[$key]) && $item[$key] == $val)
            return TRUE;
    return FALSE;
}

//-------------- GENERATE M3U -----------------//
function generateM3U($progID, $filename, $header, $prefix = NULL, $referer = NULL) {
  $json = file_get_contents($filename,0,NULL,NULL);
  $array = json_decode($json,TRUE);

  $m3u8_string = '';    
$m3u8_header = <<<'EOD'
#EXTM3U
#PLAYLIST
EOD;
  
  if(!empty($array) && !(array_key_exists('season',$array[$progID]))) {
    $counterEpisode = count($array[$progID]['episodes']);
    if ($progID == "missed" && $counterEpisode >100) {
        $counterEpisode = 100;
    }
    for ($x = 0; $x < $counterEpisode; $x++) {
      if (!array_key_exists($x, $array[$progID]['episodes']) || !array_key_exists('url', $array[$progID]['episodes'][$x]) || empty($array[$progID]['episodes'][$x]['url'])) {
        continue;
      }
      if (isset($prefix)) {
        $m3u8_string .= "\r\n#EXTINF:-1 tvg-logo=\"".$array[$progID]['episodes'][$x]['logo']."\" group-title=\"".$prefix." - ".$array[$progID]['program']."\",".$array[$progID]['episodes'][$x]['title']."\r\n";
      } else {
      	$m3u8_string .= "\r\n#EXTINF:-1 tvg-logo=\"".$array[$progID]['episodes'][$x]['logo']."\" group-title=\"".$array[$progID]['program']."\",".$array[$progID]['episodes'][$x]['title']."\r\n";
      }
      if (isset($referer) && !empty ($referer)) {
//         $m3u8_string .= "#EXTVLCOPT:http-referrer=".$referer."\r\n";
        $m3u8_string .= $array[$progID]['episodes'][$x]['url']."|Referer=".$referer;
      }
      else {
        $m3u8_string .= $array[$progID]['episodes'][$x]['url'];
      }
    }
  } else {
    //$counterSeason = count($array[$progID]['season']);
    while ($element = current($array[$progID]['season'])) {
      //echo key($array[$progID]['season'])."\n";
      if (ctype_digit(key($array[$progID]['season']))) {
        $seasonText = ' Season ';
      } else {
        $seasonText = ' | ';
      }
      $counterEpisode = count($array[$progID]['season'][key($array[$progID]['season'])]['episodes']);
      //echo $counterEpisode."\n";
      for ($x = 0; $x < $counterEpisode; $x++) {
      	if (isset($prefix)) {
          $m3u8_string .= "\r\n#EXTINF:-1 tvg-logo=\"".$array[$progID]['season'][key($array[$progID]['season'])]['episodes'][$x]['logo']."\" group-title=\"".$prefix." - ".$array[$progID]['program'].$seasonText. key($array[$progID]['season']) ."\",".$array[$progID]['season'][key($array[$progID]['season'])]['episodes'][$x]['title']."\r\n";
        } else {
          $m3u8_string .= "\r\n#EXTINF:-1 tvg-logo=\"".$array[$progID]['season'][key($array[$progID]['season'])]['episodes'][$x]['logo']."\" group-title=\"".$array[$progID]['program'].$seasonText. key($array[$progID]['season']) ."\",".$array[$progID]['season'][key($array[$progID]['season'])]['episodes'][$x]['title']."\r\n";
        }
        if (isset($referer) && !empty ($referer)) {
//           $m3u8_string .= "#EXTVLCOPT:http-referrer=".$referer."\r\n";
          $m3u8_string .= $array[$progID]['season'][key($array[$progID]['season'])]['episodes'][$x]['url']."|Referer=".$referer;
        }
        else {
          $m3u8_string .= $array[$progID]['season'][key($array[$progID]['season'])]['episodes'][$x]['url'];
        }
      }
      next ($array[$progID]['season']);
    }
  }
  if ($header) {
  	return $m3u8_header.$m3u8_string;
  } else {
    return $m3u8_string;
  }
}

//-------------- UPDATE VIDIO JSON -----------------//
function updateVidioJson($progHeader, $progID, $filename, $progURL) {
  $vodArrayURL = array();
  $isArrayGenerated = FALSE;
  
  if (!is_array($progURL)) {
    return;
  }
  if (file_exists($filename) && time()-filemtime($filename) < 6 * 3600) {
    return;
  }
  $vodArrayURL = generateVodArray($progHeader, $progID, $progURL);
  
  $json = file_get_contents($filename,0,null,null);
  $vodArray = json_decode($json,true);

  if (!empty($vodArrayURL) && count($vodArrayURL[$progID]['season'][key($vodArrayURL[$progID]['season'])]['episodes']) > count($vodArray[$progID]['season'][key($vodArray[$progID]['season'])]['episodes'])) {
      $fp = fopen($filename, 'w');
      fwrite($fp, json_encode($vodArrayURL, JSON_PRETTY_PRINT));
      fclose($fp);
  } 
}

//-------------- GENERATE VIDIO JSON -----------------//
function generateVidioJson($progHeader, $progID, $filename, $progURL) {
  global $fullpath;
  $vodArray = array();
  $isArrayGenerated = FALSE;
  
  if (is_array($progURL)) {
    $vodArray = generateVodArray($progHeader, $progID, $progURL);
    if (isset($vodArray) && !empty($vodArray)) {
      $isArrayGenerated = TRUE;
    }
  } else {
    $movId = $progURL;
    if ($progID !== $progURL ) {
      $dataArray = get_vidio_data($progID);
    } else if ($progID == $progURL) {
      $dataArray = get_vidio_watch_data($movId);
    }

    if (!empty($dataArray)) {
  	  $programName = str_replace(array(','), '',$dataArray['title']);
  	  if (empty($programName)) {
  	    $programName = $progID;
  	  }

      $vodArray[$progID]['program'] = $programName;
  	  $vodArray[$progID]['episodes'][0]['title'] = $programName;
      $vodArray[$progID]['episodes'][0]['logo'] = $dataArray['img'];
      $m3u8_url = $fullpath.'/vv_'.$dataArray['id'].'.m3u8';
  	  $vodArray[$progID]['episodes'][0]['url'] = $m3u8_url;
  	  $vodArray[$progID]['episodes'][0]['id'] = $dataArray['id'];
      $isArrayGenerated = TRUE;
    }
  }
  
  if (!$isArrayGenerated) {
    echo $offline_string;
  	die();
  } else {
    $fp = fopen($filename, 'w');
    fwrite($fp, json_encode($vodArray, JSON_PRETTY_PRINT));
    fclose($fp);
  }
}

//-------------- PREREQUISITES FUNC VIDIO JSON -----------------//
function get_vidio_id($progID) {
  if (!is_url_alive('https://m.vidio.com/premier/'.$progID)) {
    return '';
  }
  $html = file_get_html('https://m.vidio.com/premier/'.$progID, false);

  if(!empty($html)) {
    $divClass = $title = '';
    foreach($html->find(".profile-info__wrapper") as $divClass) {
      foreach($divClass->find('a') as $element) {
        $href = $element->href;
        $explodeHref = explode('/', $href);
        $explodeId = explode('-', $explodeHref[2]);
        return $explodeId[0];
      }
    }
  }
  return '';
}

//-------------- PREREQUISITES FUNC VIDIO JSON -----------------//
function get_vidio_title($progID) {
  if (!is_url_alive('https://m.vidio.com/premier/'.$progID)) {
    return '';
  }
  $html = file_get_html('https://m.vidio.com/premier/'.$progID, false);

  if(!empty($html)) {
    $divClass = $title = '';
    foreach($html->find(".profile-info__wrapper") as $divClass) {
      foreach($divClass->find(".profile-info__title") as $title ) { 
        return rtrim($title->plaintext);
      }
    }
  }
  return '';
}

//-------------- PREREQUISITES FUNC VIDIO JSON -----------------//
function get_vidio_data($progID) {
  $url = 'https://m.vidio.com/premier/'.$progID;
  if (!is_url_alive($url)) {
    return '';
  }
  $html = file_get_html($url, false);

  $data = array();
  if(!empty($html)) {
    $divClass = $title = '';
    foreach($html->find(".profile-info__wrapper") as $divClass) {
      foreach($divClass->find(".profile-info__title") as $title ) { 
        $data['title'] =  rtrim($title->plaintext);
        break;
      }
      foreach($divClass->find('a') as $element) {
        $href = $element->href;
        $explodeHref = explode('/', $href);
        $explodeId = explode('-', $explodeHref[2]);
        $data['id'] =  $explodeId[0];
        break;
      }
      foreach($divClass->find('img') as $img) {
        $data['img'] =  $img->{'data-src'}; 
        break;
      }
    }
  }
  return $data;
}

//-------------- PREREQUISITES FUNC VIDIO JSON -----------------//
function get_vidio_watch_data($progID) {
  $url = 'https://www.vidio.com/watch/'.$progID;
  if (!is_url_alive($url)) {
    return '';
  }
  $html = file_get_html($url, false);

  $data = array();
  if(!empty($html)) {
    $divClass = $title = '';
    foreach($html->find(".player-column") as $divClass) {
      foreach($divClass->find(".video-property__title") as $title ) { 
        $data['title'] = $title->plaintext;
        break;
      }
      foreach($divClass->find(".hide_me") as $img ) { 
        $data['img'] = $img->{'data-video-image-url'};
        break;
      }
    }
  }
  if (array_key_exists('title', $data) && array_key_exists('img', $data)) {
    $explodeHref = explode('/', $url);
    $data['id'] = $explodeHref[array_key_last($explodeHref)];
  }
  return $data;
}

//-------------- PREREQUISITES FUNC VIDIO JSON -----------------//
function generateVodArray($progHeader, $progID, $progURL) {
  global $fullpath;
  $isArrayGenerated = FALSE;
  foreach($progURL as $key => $value) {
    $nextPage = TRUE;
    $page = 1;
    while ($nextPage) {
      $progArray = getDataFromCurl($progURL[$key]['url'].'?page[size]=20&page[number]='.$page, $progHeader);
      if (!empty($progArray) && array_key_exists('data',$progArray) && count($progArray['data']) > 0) {
  	    $str = str_replace(array(','), '',$progArray['data'][array_key_last($progArray['data'])]['attributes']['title']);
  	    $programName = get_vidio_title ($progID);
  	    if (empty($programName)) {
  	      $programName = $progID;
  	    }

        $vodArray[$progID]['program'] = $programName;
  	    $counterEpisode = count($progArray['data']);
  	    
  	    $episodeCont = 0;
  	    if (array_key_exists('season', $vodArray[$progID]) && array_key_exists($progURL[$key]['group'], $vodArray[$progID]['season']) && count($vodArray[$progID]['season'][$progURL[$key]['group']]['episodes']) > 0) {
  	      $episodeCont = array_key_last ( $vodArray[$progID]['season'][$progURL[$key]['group']]['episodes'] ) + 1;
  	    }
  	    
  	    for ($x = 0; $x < $counterEpisode; $x++) {
  	  	  $vodArray[$progID]['season'][$progURL[$key]['group']]['episodes'][$x+$episodeCont]['title'] = rtrim(str_replace(array(',','(Trailer Promo)'), '',$progArray['data'][$x]['attributes']['title']));
  		  $vodArray[$progID]['season'][$progURL[$key]['group']]['episodes'][$x+$episodeCont]['logo'] = $progArray['data'][$x]['attributes']['cover_url'];
  		  $m3u8_url = $fullpath.'/vv_'.$progArray['data'][$x]['id'].'.m3u8';
  		  $vodArray[$progID]['season'][$progURL[$key]['group']]['episodes'][$x+$episodeCont]['url'] = $m3u8_url;
  		  $vodArray[$progID]['season'][$progURL[$key]['group']]['episodes'][$x+$episodeCont]['id'] = $progArray['data'][$x]['id'];
        }
     
        $isArrayGenerated = TRUE;
        
        if (empty($progArray['links']['next']) || is_null($progArray['links']['next'])) {
          $nextPage = FALSE;
        }
        $page++;
      }
    }
  }
  
  if ($isArrayGenerated) {
    return $vodArray;
  } else {
    return NULL;
  }
}

//-------------- PREREQUISITES FUNC VIDIO JSON -----------------//
function get_vidio_playlist_url ($progID, $api_key) {
  $playlistUrl = 'https://api.vidio.com/content_profiles/'.$progID.'/playlists';
  $playlistHeader = array(
    'Accept: */*',
    'Content-Type: application/vnd.api+json',
    'Origin: https://m.vidio.com',
    'Accept-Encoding: gzip, deflate',
    'Host: api.vidio.com',
    'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
    'Referer: https://m.vidio.com/',
    'Accept-Language: en-us',
    'Connection: keep-alive',
    'X-API-KEY: '.$api_key
  );
  $playlistArray = getDataFromCurl($playlistUrl, $playlistHeader);
  
  if (empty($playlistArray) || !array_key_exists('data',$playlistArray)) {
  	return '';
  }
  
  $playlist = array(); $i = 0;
  foreach($playlistArray['data'] as $key => $value) {
  	$wordcheck = strtolower($playlistArray['data'][$key]['attributes']['name']);
  	
  	$words = array('teaser', 'trailer');
  	if (!contains_word($words, $wordcheck)) {
  	  $playlist[$i]['group'] = $playlistArray['data'][$key]['attributes']['name'];
  	  $playlist[$i]['url'] = $playlistArray['data'][$key]['relationships']['videos']['links']['related'];
  	  $i++;
  	} 
  }
  return $playlist;
}

//-------------- PREREQUISITES FUNC VIDIO JSON -----------------//
function get_vidio_auth() {
  $authUri = 'https://www.vidio.com/auth';
  $authHeader = array(
    'Accept: */*',
    'Origin: https://www.vidio.com',
    'Accept-Encoding: gzip, deflate',
    'Host: www.vidio.com',
    'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
    'Content-Length: 0',
    'Accept-Language: en-us',
    'Connection: keep-alive'
  );
  
  $authArray = getDataFromCurl($authUri, $authHeader, NULL, 'POST');
  
  if (!empty($authArray) && array_key_exists ('api_key', $authArray)) {
  	return $authArray['api_key'];
  }
  return '';
}
