LICENSE AGREEMENT / PERSETUJUAN LISENSI:
========================================
Dengan membeli script ini anda telah menyetujui hal-hal berikut ini:
1. Walapun script sedemikian rumit untuk menghindari banned dari provider/penyedia, penulis script tidak bertanggung jawab jika account anda terkena banned.
2. Penulis script senantiasa memperbaiki script dan akan memberikan update selama dalam masa 1 (satu) tahun terhitung transaksi pembelian script.
3. Penyalahgunaan script diluar tanggung jawab penulis script.
4. Script tidak dapat dipindah tangankan.
5. Script hanya berlaku pada 1 domain sesuai persetujuan, jika domain berubah mohon info penulis.
6. Penulis script hanya bersedia membantu dan memberikan update kepada individu yang membeli script ini.
7. Script ini berlaku seumur hidup dan tidak ada biaya periode untuk lisensi.
8 . Refund tidak berlaku untuk pembelian script.
8. Jika masa update script berakhir (1 tahun terhitung transaksi) anda dapat melanjutkan untuk tahun berikutnya (GUARANTEE SERVICE) dengan biaya yang sudah disetujui.
9. GUARANTEE SERVICE tidak wajib dilakukan.
10. Jika terjadi masalah diluar periode dan tidak membeli GUARANTEE SERVICE penulis bersedia membantu dengan biaya setengah dari harga pembelian script.
11. Dapat dilakukan refund pada GUARANTEE SERVICE apabila pada masa GUARANTEE SERVICE penulis script tidak bisa menyelesaikan masalah, dengan mengembalikan setengah dari harga GUARANTEE SERVICE dan GUARANTEE SERVICE dianggap invalid.
12. LICENSE AGREEMENT / PERSETUJUAN LISENSI dapat berubah dengan menginformasikan melalui email.

Instruksi:
=======
1. Pindahkan semua file pada hosting anda
2. Jika anda mengubah directory, edit directory sesuai dengan directory anda pada file .htaccess
3. Edit vidio-cookie.json tambahkan _vidio_session sesuai dengan cookie login anda
4. Edit vv.php tambahkan remember_user_token sesuai dengan cookie login anda

Wajib diperhatikan:
==============
1. vidio_cookie.json harus selalu berubah isinya (otomatis) jika tidak berubah hubungi penulis untuk dilakukan cek.
2. contoh untuk mengakses channel, misal SCTV: 
    - https://domain.anda/vidio/vidio_sctv.m3u8
3. contoh untuk men-generate vod vidio, misal doraemon https://www.vidio.com/premier/3065/stand-by-me-doraemon-2:
    - https://domain.anda/vidio/vidiovod_3065.m3u

Jika ada masalah pada script, hubungi: https://t.me/ADavid
sertakan kode yang tertera pada akhir file readme.txt ini

==AED4B4BA299E6F44FFD1A96AE4624==