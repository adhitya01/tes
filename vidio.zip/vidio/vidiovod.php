<?php
require_once(__DIR__.'/eligible_func.php');

//-------------- MAIN() -----------------//

if ( isset($_GET['program'] ) && uri_extension($_SERVER['REQUEST_URI']) == 'm3u' && ctype_digit($_GET['program']) ) {
  $progID = filter_input(INPUT_GET,"program",FILTER_SANITIZE_STRING);
  
  $movie = FALSE;
  $filename = __DIR__.'/vidio/'.$progID.'.json';
  $api_key = get_vidio_auth();
  $playlistUrl = get_vidio_playlist_url($progID, $api_key);
  if (empty($playlistUrl)) {
    $videoId = get_vidio_id($progID);
    if (empty($videoId)) {
      $m3u8_url =  'https://m.vidio.com/videos/'.$progID.'/common_tokenized_playlist.m3u8';
      if (is_url_alive($m3u8_url)) {
        $playlistUrl = $progID;
        $movie = TRUE;
      } else {
  	    echo $offline_string;
  	    die();
  	  }
    } 
    else {
      $playlistUrl = $videoId;  
    }
  }
  
  $progHeader = array(
    'Accept: */*',
    'Content-Type: application/vnd.api+json',
    'Origin: https://m.vidio.com',
    'Accept-Encoding: gzip, deflate',
    'Host: api.vidio.com',
    'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
    'Accept-Language: en-us',
    'Connection: keep-alive',
    'X-API-KEY: '.$api_key
  );  

  if (file_exists($filename)) {
    if (!$movie) {
      updateVidioJson($progHeader, $progID, $filename, $playlistUrl);
    }
  } else {
    generateVidioJson($progHeader, $progID, $filename, $playlistUrl);
  }
  $m3uData = generateM3U($progID, $filename, TRUE, "VOD");  
  echo $m3uData;
  die();
} else {
  http_response_code(404);
  echo "Not found.";
  //include($_SERVER['DOCUMENT_ROOT'] . '/404.shtml');
  die();
}