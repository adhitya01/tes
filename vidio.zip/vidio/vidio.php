<?php
require_once(__DIR__.'/eligible_func.php');

$free_channel = array (204, 205, 665, 206, 874, 6165, 777, 875, 733, 6441, 734, 870, 5415, 778, 1561, 5409, 6166, 6711, 7432, 6482, 7004, 7443, 7184, 7092, 7057, 7188, 7166, 7449, 7091, 7053, 7248, 7297, 7055, 7242, 7130, 7445, 7056, 7447, 7054, 7448, 7450, 7284, 7283, 7281, 7446, 7216, 7169, 7218, 5075, 7687, 7946, 8024, 7685, 7792, 7684, 7170);

$channel_list = array (
  //nasional
  'sctv' => array (204),
  'indosiar' => array(8013, 7951, 205),
  'rcti' => array(665),
  'ochannel' => array(206),
  'kompastv' => array(874),
  'beritasatu' => array(6165),
  'metrotv' => array(777),
  'nettv' => array(875),
  'transtv' => array(733),
  'tvri' => array(6441),
  'trans7' => array(734),
  'mnctv' => array(870),
  'jaktv' => array(5415),
  'gtv' => array(778),
  'rtv' => array(1561),
  'inews' => array(5409),
  'oshop' => array(6166),
  'mytv' => array(6711),
  'nusantaratv' => array(7432),
  'daaitv' => array(6482),
  //sport
  'championstv1' => array(6685),
  'championstv2' => array(6686),
  'championstv3' => array(6786),
  'lfctv' => array(7916),  //<< NEW
  //entertainment
  'tvn' => array(6362),  
  'zeebioskop' => array(6399),
  'citrabioskop' => array(6684),
  'citradrama' => array(6401),
  'citradangdut' => array(6587),
  'citraentertainment' => array(6402),
  'zing' => array(6747),
  'arirang' => array(6784),
  'magnatv' => array(7230),
  'molafree' => array(6840),
  'rockent' => array(8120),
  'rockext' => array(8121),
  'musica' => array(7619),  //<< NEW
  //news
  'newsasia' => array(6411),
  'aljazeera' => array(6410),
  'euronews' => array(6412),
  'dwenglish' => array(5075),
  'abcaustralia' => array(7150),
  'seatoday' => array(7687),  //<< NEW
  'tvtempo' => array(7946),  //<< NEW
  //kids
  'hiphiphoree' => array(7052),
  'zoomoo' => array(6533),
  'davinci' => array(6549),
  'horee' => array(6397),
  'smithsonian' => array(6550),
  'lovenature' => array(6635),
  'tvedukasi' => array(6838),
  //religious
  'ajwatv' => array(7464),
  'alquranalkareem' => array(6852),
  'reformed21' => array(6853),
  'citramuslim' => array(6678),
  'uchannel' => array(6898),
  //radio
  'iradio' => array(7057),
  'prambors' => array(7004),
  'genfm' => array(7443),
  'ardan' => array(7184),
  'elshinta' => array(7166),
  'hardrockfm' => array(7053),
  'deltafm' => array(7092),
  'indika' => array(8024), //<< NEW
  'mgtradio' => array(7188),
  'kisfm' => array(7445),
  'traxfm' => array(7055),
  'cosmopolitan' => array(7056),
  'jakfm' => array(7449),
  'brava' => array(7054),
  'cakrafm' => array(7297),
  'bahana' => array(7091),
  'paramuda' => array(7685), //<< NEW
  'mustangfm' => array(7447),
  'jizfm' => array(7792),  //<< NEW
  'swaragama' => array(7248),
  'femalefm' => array(7130),
  'dahliafm' => array(7242),
  'genfmsurabaya' => array(7446),
  'mostfm' => array(7450),
  'hotfm' => array(7448),
  'ramafm' => array(7684),  //<< NEW
  'gajahmada' => array(7284),
  'swarasemarang' => array(7283),
  'geronimo' => array(7216),
  'imeldafm' => array(7281),
  'sushiradio' => array(7218),
  'elgangga' => array(7169),
  'elmitra' => array(7170),
  //other
  'mdl' => array(7646)
);

$m3u_header = "#EXTM3U\r\n";
$m3u_header .= "#EXT-X-VERSION:3\r\n";

if ( isset($_GET['channel'] ) && uri_extension($_SERVER['REQUEST_URI']) == 'm3u8') {
  $inputString = strtolower(filter_input(INPUT_GET,"channel",FILTER_SANITIZE_STRING));
  if (array_key_exists($inputString, $channel_list)) {
    $channelSlug = $inputString;
  } else {
  	http_response_code(404);
    echo "<html>\r\n<head><title>404 Not Found</title></head>\r\n<body bgcolor=\"white\">\r\n<center><h1>404 Not Found</h1></center>\r\n<hr><center>nginx</center>\r\n</body>\r\n</html>";
  	die();
  }
} else {
  http_response_code(404);
  echo "<html>\r\n<head><title>404 Not Found</title></head>\r\n<body bgcolor=\"white\">\r\n<center><h1>404 Not Found</h1></center>\r\n<hr><center>nginx</center>\r\n</body>\r\n</html>";
  die();
}

foreach($channel_list[$channelSlug] as $key => $value) {
  $token_url = 'https://www.vidio.com/live/'.$value.'/tokens';

  $vidioCookie_file = __DIR__.'/vidio-freecookie.json';
  $vidioCache_file = __DIR__.'/vidio-cache/'.$value.'.json';
  
  if (file_exists($vidioCache_file)) {   
    $json = file_get_contents($vidioCache_file,0,NULL,NULL);
    $vidioCacheArray = json_decode($json,TRUE);
    if ( time() - 100 < $vidioCacheArray['expired'] ) {
      echo $vidioCacheArray['hls'];
  	  die();
  	}
    if ( array_key_exists('m3u8', $vidioCacheArray) && is_url_alive($vidioCacheArray['m3u8']) ) {
      $hls_output = get_original_url($vidioCacheArray['m3u8'], $userAgentDesktop);
      if (isset($hls_output) && !empty($hls_output)) {
        $vidioCache['hls'] = $hls_output;
        $vidioCache['m3u8'] = $vidioCacheArray['m3u8'];
        $vidioCache['expired'] = (int) time() + 14400;
        $fp = fopen($vidioCache_file, 'w');
        fwrite($fp, json_encode($vidioCache, JSON_PRETTY_PRINT));
        fclose($fp);
        
        echo $hls_output;
        die();
      }
    }
  }
  
  if ( !in_array($value, $free_channel) ) {
    continue;
  }
  if (!file_exists($vidioCookie_file)) {   
    echo $offline_string;
    die();
  }
  
  $cookieJson = file_get_contents($vidioCookie_file,0,null,null);
  $cookieArray = json_decode($cookieJson,true);  
  
  $userAgentDesktop = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15';
  
  $vidio_Header = array(
    'Accept: */*',
    'Origin: https://www.vidio.com',
    'Accept-Encoding: gzip, deflate, br',
    'Host: www.vidio.com',
    'User-Agent: '.$userAgentDesktop,
    'Content-Length: 0',
    'Accept-Language: en-us',
    'Connection: keep-alive',
    'Cookie: '.$cookieArray['cookie']
  );
  
  $arrayResult = getDataFromCurlWithHeaderCookie($token_url, $vidio_Header, NULL, 'POST');
  if (empty($arrayResult) || !array_key_exists('result', $arrayResult) || !isJson($arrayResult['result'])) {
    continue;
  }
  
  if (array_key_exists('_vidio_session', $arrayResult)) {
    $newCookie['cookie'] = "_vidio_session=".$arrayResult['_vidio_session'];
    $fp = fopen($vidioCookie_file, 'w');
    fwrite($fp, json_encode($newCookie, JSON_PRETTY_PRINT));
    fclose($fp);
  }
  
  $newHLSArray = json_decode($arrayResult['result'], true);
  if (empty($newHLSArray) || !array_key_exists('token', $newHLSArray)) {
    continue;
  }
  $newHLS = 'https://app-etslive-2.vidio.com/live/'.$value.'/master.m3u8?'.$newHLSArray['token'];
  
  if (is_url_alive($newHLS)) {
    $hls_output = get_original_url($newHLS, $userAgentDesktop);
    if (isset($hls_output) && !empty($hls_output)) {
      $vidioCache['hls'] = $hls_output;
      $vidioCache['m3u8'] = $newHLS;
      $vidioCache['expired'] = (int) time() + 14400;
      $fp = fopen($vidioCache_file, 'w');
      fwrite($fp, json_encode($vidioCache, JSON_PRETTY_PRINT));
      fclose($fp);
    
  	  echo $hls_output;
  	  die();
    } else {
  	  continue;
    }
  }
}

// PREMIUM \\
foreach($channel_list[$channelSlug] as $key => $value) {
  $token_url = 'https://www.vidio.com/live/'.$value.'/tokens';

  $vidioCookie_file = __DIR__.'/vidio-cookie.json';
  $vidioCache_file = __DIR__.'/vidio-cache/'.$value.'.json';
  
  if (!file_exists($vidioCookie_file)) {   
    echo $offline_string;
    die();
  }
  $cookieJson = file_get_contents($vidioCookie_file,0,null,null);
  $cookieArray = json_decode($cookieJson,true);  
  
  $userAgentDesktop = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15';
  
  $vidio_Header = array(
    'Accept: */*',
    'Origin: https://www.vidio.com',
    'Accept-Encoding: gzip, deflate, br',
    'Host: www.vidio.com',
    'User-Agent: '.$userAgentDesktop,
    'Content-Length: 0',
    'Accept-Language: en-us',
    'Connection: keep-alive',
    'Cookie: '.$cookieArray['cookie']
  );
  
  $arrayResult = getDataFromCurlWithHeaderCookie($token_url, $vidio_Header, NULL, 'POST');
  if (empty($arrayResult) || !array_key_exists('result', $arrayResult) || !isJson($arrayResult['result'])) {
    continue;
  }
  
  if (array_key_exists('_vidio_session', $arrayResult)) {
    $newCookie['cookie'] = "_vidio_session=".$arrayResult['_vidio_session'];
    $fp = fopen($vidioCookie_file, 'w');
    fwrite($fp, json_encode($newCookie, JSON_PRETTY_PRINT));
    fclose($fp);
  }
  
  $newHLSArray = json_decode($arrayResult['result'], true);
  if (empty($newHLSArray) || !array_key_exists('token', $newHLSArray)) {
    echo $offline_string;
    die();
  }
  $newHLS = 'https://app-etslive-2.vidio.com/live/'.$value.'/master.m3u8?'.$newHLSArray['token'];
  
  if (is_url_alive($newHLS)) {
    $hls_output = get_original_url($newHLS, $userAgentDesktop);
    if (isset($hls_output) && !empty($hls_output)) {
      $vidioCache['hls'] = $hls_output;
      $vidioCache['m3u8'] = $newHLS;
      $vidioCache['expired'] = (int) time() + 14400;
      $fp = fopen($vidioCache_file, 'w');
      fwrite($fp, json_encode($vidioCache, JSON_PRETTY_PRINT));
      fclose($fp);
    
  	  echo $hls_output;
  	  die();
    } else {
  	  echo $offline_string;
      die();
    }
  }
}
echo $unauthorized_string;
die();